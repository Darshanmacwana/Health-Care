package healthcarefinal.com.heatlhcarefinal;

public class Disease {
    String diseasename,diseaseinfo,diseaselink;
}
