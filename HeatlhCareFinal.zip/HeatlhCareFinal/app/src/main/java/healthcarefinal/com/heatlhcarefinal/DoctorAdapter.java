package healthcarefinal.com.heatlhcarefinal;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.MyViewHolder> {
    private List<Doctor> moviesList;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView dname, did, dage, dposition;
        Button button;

        public MyViewHolder(final View view) {
            super(view);
            dname = (TextView) view.findViewById(R.id.nameid);
            did = (TextView) view.findViewById(R.id.doctorid);
            dage = (TextView) view.findViewById(R.id.ageid);
            dposition = (TextView) view.findViewById(R.id.position);
            button = (Button) view.findViewById(R.id.appointbuttonid);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), BookAppointment.class);
                    intent.putExtra("name", dname.getText().toString());
                    intent.putExtra("id", did.getText().toString());
                    v.getContext().startActivity(intent);
                }
            });
        }
    }


    public DoctorAdapter(List<Doctor> moviesList) {
        this.moviesList = moviesList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.doctorsinfo, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Doctor movie = moviesList.get(position);
        holder.dname.setText(movie.getDname());
        holder.dage.setText(movie.getAge());
        holder.dposition.setText(movie.getPosition());
        holder.did.setText(movie.getId());

    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}

