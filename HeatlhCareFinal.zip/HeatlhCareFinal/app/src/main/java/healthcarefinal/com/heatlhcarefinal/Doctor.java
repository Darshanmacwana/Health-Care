package healthcarefinal.com.heatlhcarefinal;

public class Doctor {
    String dname;
    String age;
    String position;
    String id;
    public Doctor(String dname, String age, String position, String id, String gender) {
        this.dname = dname;
        this.age = age;
        this.position = position;
        this.id = id;
        this.gender = gender;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    String gender;


    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }


    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
