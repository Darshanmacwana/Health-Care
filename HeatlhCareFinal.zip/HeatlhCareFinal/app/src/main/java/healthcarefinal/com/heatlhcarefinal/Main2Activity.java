package healthcarefinal.com.heatlhcarefinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
RecyclerView recyclerView;
    private List<Doctor> movieList = new ArrayList<>();
    DoctorAdapter mAdapter;
    String cat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent=getIntent();
        cat=intent.getStringExtra("c");
Toast.makeText(Main2Activity.this,cat,Toast.LENGTH_LONG).show();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerid);
        mAdapter = new DoctorAdapter(movieList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        prepareMovieData();
    }
    private void prepareMovieData() {
        switch (cat) {
            case "Cardiac Surgeon": {
                Doctor doctor = new Doctor("Dr Ketan Patel", "26", "Senior Cardiac Surgeon", "1001", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Parva Patel", "20", "Senior Cardiac Surgeon", "1002", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Aayush Patel", "25", "Senior Cardiac Surgeon", "1003", "m");
                movieList.add(doctor);


                break;
            }
            case "Orthopedic": {
                Doctor doctor = new Doctor("Dr abhishek Patel", "26", "Senior orthopedic Surgeon", "1004", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr dhaval Patel", "26", "Orthopedic Surgeon", "1005", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr parth Patel", "26", "Orthopedic consultant ", "1006", "m");
                movieList.add(doctor);


                break;
            }
            case "General doctor": {
                Doctor doctor = new Doctor("Dr Karan Patel", "26", "Seniour Physician", "1007", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Ronaldo Patel", "26", "Jr Physcian", "1008", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Messi Patel", "26", "Physiscian", "1009", "m");
                movieList.add(doctor);


                break;
            }
            case "Dental care": {
                Doctor doctor = new Doctor("Dr Rusabh Patel", "26", "Dentist", "1010", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Aakash Patel", "26", "Dentist", "1011", "m");
                movieList.add(doctor);
                doctor = new Doctor("Dr Marcelo Viera", "26", "Dentist", "1012", "m");
                movieList.add(doctor);


                break;
            }
        }

        mAdapter.notifyDataSetChanged();
    }

}
