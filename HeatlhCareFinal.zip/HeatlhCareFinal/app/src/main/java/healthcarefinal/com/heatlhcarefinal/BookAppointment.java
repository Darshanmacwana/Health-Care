package healthcarefinal.com.heatlhcarefinal;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class BookAppointment extends AppCompatActivity {
    EditText pname, page, pno;
    String inserturl = "https://patelaayush678.000webhostapp.com/insert_query1.php";
    TextView textView,textid,textname;
    Button button;
    private DatePickerDialog.OnDateSetListener mDateSetListner;
    Calendar cal = Calendar.getInstance();
String dname,did;
String phoneNo,message;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);
        Intent intent = getIntent();
         dname = intent.getStringExtra("name");
         did = intent.getStringExtra("id");
     //   Toast.makeText(BookAppointment.this, name + "" + id, Toast.LENGTH_LONG).show();
        pname = (EditText) findViewById(R.id.nameidid);
        page = (EditText) findViewById(R.id.ageidid);
        pno = (EditText) findViewById(R.id.phonenoidid);
        textView = (TextView) findViewById(R.id.calenderid);
        textid = (TextView) findViewById(R.id.iddoctor);textname = (TextView) findViewById(R.id.doctornameidid);
        textid.setText(did);
        textname.setText(dname);
        button = (Button) findViewById(R.id.apid);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(BookAppointment.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, mDateSetListner, year, month, day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });
        mDateSetListner = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String date = year + "/" + month + "/" + day;
                if (year == cal.get(Calendar.YEAR)) {
                    textView.setText(date);
                } else {
                    Toast.makeText(BookAppointment.this, "select this year only ", Toast.LENGTH_LONG).show();
                }


            }
        };
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(validate()==true) {
                   final ProgressDialog progressDialog = new ProgressDialog(BookAppointment.this);
                   progressDialog.setMessage("sending");
                   progressDialog.setCancelable(false);
                   progressDialog.show();

                   final StringRequest stringRequest = new StringRequest(Request.Method.POST, inserturl, new Response.Listener<String>() {
                       @Override
                       public void onResponse(String response) {
                           progressDialog.dismiss();
sendSMSMessage();
//                        name.setText("");
//                        email.setText("");
//                        form.setText("");
//                        phone.setText("");
//                        collegeid.setText("");
                       }
                   }, new Response.ErrorListener() {
                       @Override
                       public void onErrorResponse(VolleyError error) {

                           Toast.makeText(BookAppointment.this, "Error" + error, Toast.LENGTH_SHORT).show();

                       }
                   }) {
                       @Override
                       protected Map<String, String> getParams() throws AuthFailureError {

                           //   System.out.println("Data is " + it.next());

                           final Map<String, String> params = new HashMap<String, String>();
                           params.put("pname", pname.getText().toString());
                           params.put("page", page.getText().toString());
                           params.put("pphoneno", pno.getText().toString());
                           params.put("doctorname", dname);
                           params.put("doctorid", did);
                           params.put("appointmentdate", textView.getText().toString());

                           return params;
                       }

                   };
                   RequestQueue requestQueue = Volley.newRequestQueue(BookAppointment.this);
                   requestQueue.add(stringRequest);
               }
            }
        });


    }
    protected void sendSMSMessage() {
        phoneNo = pno.getText().toString();
        message = "Thank You "+pname.getText().toString()+" for booking an appointment with "+dname+"on date :"+textView.getText().toString();

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo, null, message, null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS faild, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
    }
    public boolean validate() {
        boolean valid = true;

        //Integer nn=Integer.valueOf(phoneed.getText().toString());

        if (pname.getText().toString().isEmpty()) {
            pname.setError("Please enter name ");
            valid = false;
        } else {
            pname.setError(null);
        }
        if (pno.getText().toString().isEmpty()) {
            pno.setError("Please enter phoneno ");
            valid = false;
        } else {
            pno.setError(null);
        }
        if (page.getText().toString().isEmpty()) {
            page.setError("Please enter valid  age ");
            valid = false;
        } else {
            page.setError(null);
        }
        if (textView.getText().toString().isEmpty()) {
            textView.setError("Please select date ");
            valid = false;
        } else {
            textView.setError(null);
        }
        return valid;
    }
}
